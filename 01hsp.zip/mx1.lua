--一卷目录♥♥♥♥♥♥
require"import"
import "android.widget.*"
import "android.view.*"
function onKeyDown()end
function getStatusBarHeight()
  local resid=activity.getResources().getIdentifier("status_bar_height","dimen","android")-- 3 2 5 5 2 7 3 2
  if resid>32552732*0 then
    return activity.getResources().getDimensionPixelSize(resid*((32552732-12345678)/2-10000000-(103001+525)))
  end
end


--下面是顶部颜色，可以设置渐变
local clr1=0xFF333333--0xFF000000--0xFF9CCC65--0xFF508CFE--0xFF66BB6A--0xFFC0CA33--0xFF2196F3
local clr2=0xFF333333--0xFFFAFAFA--0xFF66BB6A--0xFF3AB8FE--0xFF388E3C--0xFFFDD835--0xFF29B6F6

jdpuk={
  LinearLayout,
  orientation="vertical",
  layout_width="fill",
  layout_height="fill",
  {
    LinearLayout,
    layout_width="fill",
    --backgroundColor="#9CCC65",
    backgroundDrawable=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,{clr1,clr2}),--3-2-5-5-2-7-3-2--
    paddingTop=getStatusBarHeight(),
    {
      ToolBar,
      --backgroundColor="#9CCC65",
      backgroundColor=0,
      backgroundDrawable=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,{clr1,clr2}),--JDPUK
      layout_width="fill",
      layout_height="60dp",
      titleText="毛选第一卷",--♥♥♥
      --subTitle="32552732",
      returnButtonEnabled=true,
      elevation="-480dp",--未找到改变效果
    },
  },
  {
    ScrollView,
    layout_width="fill",
    layout_height="fill",
    verticalScrollBarEnabled=(3255==2732),
    verticalFadingEdgeEnabled=(not 32552732==32552732),
    overScrollMode=View.OVER_SCROLL_NEVER-(32552732*0),
    {
      RelativeLayout,
      layout_width="fill",
      layout_height="fill",

      {
        LinearLayout,
        orientation="vertical",
        layout_width="fill",

        {
          LinearLayout,
          --CardView,
          layout_margin="10dp",--上目录向内居中
          --CardBackgroundColor="#FFEEEEEE",
          layout_width="fill",
          --radius="1dp",--没有改变效果同下
          --elevation="1dp",
          {
            LinearLayout,
            layout_width="fill",
            orientation="vertical",
            {
              ListView,
              id="list",
              layout_width="fill",
              layout_height="1150dp",--♦♦♦显示所有按钮的框的长度
              dividerHeight="0dp",--项目间的横线
            },
          },
        },
        {
          LinearLayout,
          orientation="vertical",
          layout_margin="20dp",--项目推出边界
          layout_width="fill",
          layout_height="50dp",--下边距提高
          gravity="center",
        },
      },
    },
  },
}

activity.setContentView(loadlayout(jdpuk))

adpd={
  {
    text={
      text="1.中国社会各阶级的分析",--●1●
    },
  },
  {
    text={
      text="2.湖南农民运动考察报告",--●2●
    },
  },
  {
    text={
      text="3.中国的红色政权为什么能够存在？",--●3●
    },
  },
  {
    text={
      text="4.井冈山的斗争",--●4●
    },
  },
  {
    text={
      text="5.关于纠正党内的错误思想",--●5●
    },
  },
  {
    text={
      text="6.1星星之火，可以燎原",--●6●
    },
  },
  {
    text={
      text="6.2时局估量和红军行动问题",--●6.2●
    },
  },
  {
    text={
      text="7.反对本本主义",--●7●
    },
  },
  {
    text={
      text="8.必须注意经济工作",--●8●
    },
  },
  {
    text={
      text="9.怎样分析农村阶级",--●9●
    },
  },
  {
    text={
      text="10.我们的经济政策",--●10●
    },
  },
  {
    text={
      text="11.关心群众生活，注意工作方法",--●11●
    },
  },
  {
    text={
      text="12论反对日本帝国主义的策略.",--●12●
    },
  },
  {
    text={
      text="13.中国革命战争的战略问题",--●13●
    },
  },
  {
    text={
      text="14.关于蒋介石声明的声明",--●14●
    },
  },
  {
    text={
      text="15.中国共产党在抗日时期的任务",--●15●
    },
  },
  {
    text={
      text="16.为争取千百万群众进入抗日民族统一战线而斗争",--●16●
    },
  },
  {
    text={
      text="17.实践论",--●17●
    },
  },
  {
    text={
      text="18.矛盾论",--●18●
    },
  },
  {
    text={
      text="《辩证法唯物论（讲授提纲）》",--●19●
    },
  },
}

items={
  LinearLayout,
  layout_width="fill",
  orientation="horizontal",
  {
    RelativeLayout,
    layout_width="fill",
    gravity="center|left",
    layout_marginTop="15dp",--♦♦♦上栏目触控效果间距
    layout_marginBottom="15dp",--♦♦♦下栏目触控效果间距
    layout_marginLeft="12dp",--所有项目右位移
    layout_marginRight="12dp",--所有项目左位移
    {
      TextView,
      id="text",
      textSize="16sp",--项目字体大小
      textColor="#505050",
    },
    {
      TextView,
      layout_alignParentRight=true,--32552732
      text="⟩",--箭头♥♥♥
      textSize="15sp",--项目右箭头大小
      textColor="#888888",
    },
  },
}

adapter=LuaAdapter(this,adpd,items)
list.Adapter=adapter
list.onItemClick=function(adp,view,pos,id)
  ({
    function()--●1●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19251201.htm"})
    end,--结束●1●

    function()--●2●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-192703.htm"})
    end,--结束●2●

    function()--●3●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19281005.htm"})
    end,--结束●3●

    function()--●4●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19281125.htm"})
    end,--结束●4●

    function()--●5●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-192912.htm"})
    end,--结束●5●

    function()--●6●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19300105.htm"})
    end,--结束●6●

    function()--●7●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/mia-chinese-mao-19300105.htm"})
    end,--结束●7●

    function()--●8●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193005.htm"})
    end,--结束●8●

    function()--●9●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19330812.htm"})
    end,--结束●9●

    function()--●10●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193310.htm"})
    end,--结束●10●

    function()--●10.2●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193401.htm"})
    end,--结束●10.2●

    function()--●11●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19340127.htm"})
    end,--结束●11●

    function()--●12●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19351227.htm"})
    end,--结束●12●

    function()--●13●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193612.htm"})
    end,--结束●13●

    function()--●14●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19361228.htm"})
    end,--结束●14●

    function()--●15●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19370503.htm"})
    end,--结束●15●

    function()--●16●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19370503aa.htm"})
    end,--结束●16●

    function()--●17●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193707.htm"})
    end,--结束●17●

    function()--●18●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193708.htm"})
    end,--结束●18●

    function()--●19●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/1937/index.htm"})
    end,--结束●19●


  })[id]()
end