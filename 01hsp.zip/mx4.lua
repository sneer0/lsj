--四卷目录♥♥♥♥♥♥
require"import"
import "android.widget.*"
import "android.view.*"
function onKeyDown()end
function getStatusBarHeight()
  local resid=activity.getResources().getIdentifier("status_bar_height","dimen","android")-- 3 2 5 5 2 7 3 2
  if resid>32552732*0 then
    return activity.getResources().getDimensionPixelSize(resid*((32552732-12345678)/2-10000000-(103001+525)))
  end
end


--下面是顶部颜色，可以设置渐变
local clr1=0xFF333333--0xFF000000--0xFF9CCC65--0xFF508CFE--0xFF66BB6A--0xFFC0CA33--0xFF2196F3
local clr2=0xFF333333--0xFFFAFAFA--0xFF66BB6A--0xFF3AB8FE--0xFF388E3C--0xFFFDD835--0xFF29B6F6

jdpuk={
  LinearLayout,
  orientation="vertical",
  layout_width="fill",
  layout_height="fill",
  {
    LinearLayout,
    layout_width="fill",
    --backgroundColor="#9CCC65",
    backgroundDrawable=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,{clr1,clr2}),--3-2-5-5-2-7-3-2--
    paddingTop=getStatusBarHeight(),
    {
      ToolBar,
      --backgroundColor="#9CCC65",
      backgroundColor=0,
      backgroundDrawable=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,{clr1,clr2}),--JDPUK
      layout_width="fill",
      layout_height="60dp",
      titleText="毛选第四卷",--♥♥♥
      --subTitle="32552732",
      returnButtonEnabled=true,
      elevation="-480dp",--未找到改变效果
    },
  },
  {
    ScrollView,
    layout_width="fill",
    layout_height="fill",
    verticalScrollBarEnabled=(3255==2732),
    verticalFadingEdgeEnabled=(not 32552732==32552732),
    overScrollMode=View.OVER_SCROLL_NEVER-(32552732*0),
    {
      RelativeLayout,
      layout_width="fill",
      layout_height="fill",

      {
        LinearLayout,
        orientation="vertical",
        layout_width="fill",

        {
          LinearLayout,
          --CardView,
          layout_margin="10dp",--上目录向内居中
          --CardBackgroundColor="#FFEEEEEE",
          layout_width="fill",
          --radius="1dp",--没有改变效果同下
          --elevation="1dp",
          {
            LinearLayout,
            layout_width="fill",
            orientation="vertical",
            {
              ListView,
              id="list",
              layout_width="fill",
              layout_height="3850dp",--♦♦♦显示所有按钮的框的长度
              dividerHeight="0dp",--项目间的横线
            },
          },
        },
        {
          LinearLayout,
          orientation="vertical",
          layout_margin="20dp",--项目推出边界
          layout_width="fill",
          layout_height="50dp",--下边距提高
          gravity="center",
        },
      },
    },
  },
}

activity.setContentView(loadlayout(jdpuk))

adpd={
  {
    text={
      text="1.抗日战争胜利后的时局和我们的方针",--●1●
    },
  },
  {
    text={
      text="2.蒋介石在挑动内战",--●2●
    },
  },
  {
    text={
      text="3.第十八集团军总司令给蒋介石的两个电报",--●3●
    },
  },
  {
    text={
      text="4.评蒋介石发言人谈话",--●4●
    },
  },
  {
    text={
      text="5.中共中央关于同国民党进行和平谈判的通知",--●5●
    },
  },
  {
    text={
      text="6.关于重庆谈判",--●6●
    },
  },
  {
    text={
      text="7.国民党进攻的真相",--●7●
    },
  },
  {
    text={
      text="8.减租和生产是保卫解放区的两件大事",--●8●
    },
  },
  {
    text={
      text="9.一九四六年解放区工作的方针",--●9●
    },
  },
  {
    text={
      text="10.建立巩固的东北根据地",--●10●
    },
  },
  {
    text={
      text="11.关于目前国际形势的几点估计",--●11●
    },
  },
  {
    text={
      text="12.以自卫战争粉碎蒋介石的进攻",--●12●
    },
  },
  {
    text={
      text="13.和美国记者安娜·刘易斯·斯特朗的谈话.",--●13●
    },
  },
  {
    text={
      text="14.集中优势兵力，各个歼灭敌人",--●14●
    },
  },
  {
    text={
      text="15.美国“调解”真相和中国内战前途",--●15●
    },
  },
  {
    text={
      text="16.三个月总结",--●16●
    },
  },
  {
    text={
      text="17.迎接中国革命的新高潮",--●17●
    },
  },
  {
    text={
      text="18.中共中央关于暂时放弃延安和保卫陕甘宁边区的两个文件",--●18●
    },
  },
  {
    text={
      text="19.关于西北战场的作战方针",--●19●
    },
  },
  {
    text={
      text="20.蒋介石政府已处在全民的包围中",--●20●
    },
  },
  {
    text={
      text="21.解放战争第二年的战略方针",--●21●
    },
  },
  {
    text={
      text="22.中国人民解放军宣言",--●22●
    },
  },
  {
    text={
      text="23.中国人民解放军总部关于重行颁布三大纪律八项注意的训令",--●23●
    },
  },
  {
    text={
      text="24.目前形势和我们的任务",--●24●
    },
  },
  {
    text={
      text="25.关于建立报告制度",--●25●
    },
  },
  {
    text={
      text="26.关于目前党的政策中的几个重要问题",--●26●
    },
  },
  {
    text={
      text="27.军队内部的民主运动",--●27●
    },
  },
  {
    text={
      text="28.在不同地区实施土地法的不同策略",--●28●
    },
  },
  {
    text={
      text="29.纠正土地改革宣传中的“左”倾错误",--●29●
    },
  },
  {
    text={
      text="30.新解放区土地改革要点",--●30●
    },
  },
  {
    text={
      text="31.关于工商业政策",--●31●
    },
  },
  {
    text={
      text="32.关于民族资产阶级和开明绅士问题",--●32●
    },
  },
  {
    text={
      text="33.评西北大捷兼论解放军的新式整军运动",--●33●
    },
  },
  {
    text={
      text="34.关于情况的通报",--●34●
    },
  },
  {
    text={
      text="35.在晋绥干部会议上的讲话",--●35●
    },
  },
  {
    text={
      text="36.对晋绥日报编辑人员的谈话",--●36●
    },
  },
  {
    text={
      text="37.再克洛阳后给洛阳前线指挥部的电报",--●37●
    },
  },
  {
    text={
      text="38.新解放区农村工作的策略问题",--●38●
    },
  },
  {
    text={
      text="39.一九四八年的土地改革工作和整党工作",--●39●
    },
  },
  {
    text={
      text="40.关于辽沈战役的作战方针",--●40●
    },
  },
  {
    text={
      text="41.关于健全党委制",--●41●
    },
  },
  {
    text={
      text="42.中共中央关于九月会议的通知",--●42●
    },
  },
  {
    text={
      text="43.关于淮海战役的的作战方针",--●43●
    },
  },
  {
    text={
      text="44.全世界革命力量团结起来，反对帝国主义的侵略.",--●44●
    },
  },
  {
    text={
      text="45.中国军事形势的重大变化",--●45●
    },
  },
  {
    text={
      text="46.关于平津战役的作战方针",--●46●
    },
  },
  {
    text={
      text="47.敦促杜聿明等投降书.",--●47●
    },
  },
  {
    text={
      text="48.将革命进行到底",--●48●
    },
  },
  {
    text={
      text="49.评战犯求和",--●49●
    },
  },
  {
    text={
      text="50.中共中央毛泽东主席关于时局的声明",--●50●
    },
  },
  {
    text={
      text="51.中共发言人评南京行政院的决议",--●51●
    },
  },
  {
    text={
      text="52.中共发言人关于命令国民党反动政府重新逮捕前日本侵华军总司令冈村宁次和逮捕国民党内战罪犯的谈话",--●52●
    },
  },
  {
    text={
      text="53.中共发言人关于和平条件必须包括惩办日本战犯和国民党战犯的声明",--●53●
    },
  },
  {
    text={
      text="54.把军队变为工作队",--●54●
    },
  },
  {
    text={
      text="55.四分五裂的反动派为什么还要空喊“全面和平”？",--●55●
    },
  },
  {
    text={
      text="56.国民党反动派由“呼吁和平”变为呼吁战争",--●56●
    },
  },
  {
    text={
      text="57.评国民党对战争责任问题的几种答案",--●57●
    },
  },
  {
    text={
      text="58.在中国共产党第七届中央委员会第二次全体会议上的报告",--●58●
    },
  },
  {
    text={
      text="59.党委会的工作方法",--●59●
    },
  },
  {
    text={
      text="60.南京政府向何处去？",--●60●
    },
  },
  {
    text={
      text="61.向全国进军的命令",--●61●
    },
  },
  {
    text={
      text="62.中国人民解放军布告",--●62●
    },
  },
  {
    text={
      text="63.中国人民解放军总部发言人为英国军舰暴行发表的声明",--●63●
    },
  },
  {
    text={
      text="64.在新政治协商会议筹备会上的讲话",--●64●
    },
  },
  {
    text={
      text="65.论人民民主专政",--●65●
    },
  },
  {
    text={
      text="66.丢掉幻想，准备斗争",--●66●
    },
  },
  {
    text={
      text="67.别了，司徒雷登",--●67●
    },
  },
  {
    text={
      text="68.友谊还是侵略",--●68●
    },
  },
  {
    text={
      text="69.为什么要讨论白皮书",--●69●
    },
  },
  {
    text={
      text="70.唯心历史观的破产",--●70●
    },
  },
}

items={
  LinearLayout,
  layout_width="fill",
  orientation="horizontal",
  {
    RelativeLayout,
    layout_width="fill",
    gravity="center|left",
    layout_marginTop="15dp",--♦♦♦上栏目触控效果间距
    layout_marginBottom="15dp",--♦♦♦下栏目触控效果间距
    layout_marginLeft="12dp",--所有项目右位移
    layout_marginRight="12dp",--所有项目左位移
    {
      TextView,
      id="text",
      textSize="16sp",--项目字体大小
      textColor="#505050",
    },
    {
      TextView,
      layout_alignParentRight=true,--32552732
      text="⟩",--箭头♥♥♥
      textSize="15sp",--项目右箭头大小
      textColor="#888888",
    },
  },
}

adapter=LuaAdapter(this,adpd,items)
list.Adapter=adapter
list.onItemClick=function(adp,view,pos,id)
  ({
    function()--●1●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19450813.htm"})
    end,--结束●1●

    function()--●2●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19450813b.htm"})
    end,--结束●2●

    function()--●3●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-194508.htm"})
    end,--结束●3●

    function()--●4●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19450816.htm"})
    end,--结束●4●

    function()--●5●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19450826.htm"})
    end,--结束●5●

    function()--●6●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19451017.htm"})
    end,--结束●6●

    function()--●7●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19451105.htm"})
    end,--结束●7●

    function()--●8●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19451107.htm"})
    end,--结束●8●

    function()--●9●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19451215.htm"})
    end,--结束●9●

    function()--●10●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19451228.htm"})
    end,--结束●10●

    function()--●11●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-194604.htm"})
    end,--结束●11●

    function()--●12●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19460720.htm"})
    end,--结束●12●

    function()--●13●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19460806.htm"})
    end,--结束●13●

    function()--●14●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19460916.htm"})
    end,--结束●14●

    function()--●15●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19460929.htm"})
    end,--结束●15●

    function()--●16●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19461001.htm"})
    end,--结束●16●

    function()--●17●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19470201.htm"})
    end,--结束●17●

    function()--●18●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-194611and194704.htm"})
    end,--结束●18●

    function()--●19●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19470415.htm"})
    end,--结束●19●

    function()--●20●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19470530.htm"})
    end,--结束●20●

    function()--●21●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19470901.htm"})
    end,--结束●21●

    function()--●22●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19471010.htm"})
    end,--结束●22●

    function()--●23●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19471010a.htm"})
    end,--结束●23●

    function()--●24●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19471225.htm"})
    end,--结束●24●

    function()--●25●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480107.htm"})
    end,--结束●25●

    function()--●26●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480118.htm"})
    end,--结束●26●

    function()--●27●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480130.htm"})
    end,--结束●27●

    function()--●28●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480203.htm"})
    end,--结束●28●

    function()--●29●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480211.htm"})
    end,--结束●29●

    function()--●30●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480215.htm"})
    end,--结束●30●

    function()--●31●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480227.htm"})
    end,--结束●31●

    function()--●32●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480301.htm"})
    end,--结束●32●

    function()--●33●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480307.htm"})
    end,--结束●33●

    function()--●34●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480320.htm"})
    end,--结束●34●

    function()--●35●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480401.htm"})
    end,--结束●35●

    function()--●36●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480402.htm"})
    end,--结束●36●

    function()--●37●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480408.htm"})
    end,--结束●37●

    function()--●38●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480524.htm"})
    end,--结束●38●

    function()--●39●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480525.htm"})
    end,--结束●39●

    function()--●40●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-194809and10.htm"})
    end,--结束●40●

    function()--●41●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19480920.htm"})
    end,--结束●41●

    function()--●42●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19481001.htm"})
    end,--结束●42●

    function()--●43●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19481011.htm"})
    end,--结束●43●

    function()--●44●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-194811.htm"})
    end,--结束●44●

    function()--●45●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19481114.htm"})
    end,--结束●45●

    function()--●46●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19481211.htm"})
    end,--结束●46●

    function()--●47●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19481217.htm"})
    end,--结束●47●

    function()--●48●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19481230.htm"})
    end,--结束●48●

    function()--●49●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490104.htm"})
    end,--结束●49●

    function()--●50●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490114.htm"})
    end,--结束●50●

    function()--●51●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490121.htm"})
    end,--结束●51●

    function()--●52●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490128.htm"})
    end,--结束●52●

    function()--●53●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490205.htm"})
    end,--结束●53●

    function()--●54●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490208a.htm"})
    end,--结束●54●

    function()--●55●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490215.htm"})
    end,--结束●55●

    function()--●56●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490216.htm"})
    end,--结束●56●

    function()--●57●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490218.htm"})
    end,--结束●57●

    function()--●58●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490305.htm"})
    end,--结束●58●

    function()--●59●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490313.htm"})
    end,--结束●59●

    function()--●60●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490404.htm"})
    end,--结束●60●

    function()--●61●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490421.htm"})
    end,--结束●61●

    function()--●62●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490425.htm"})
    end,--结束●62●

    function()--●63●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490330.htm"})
    end,--结束●63●

    function()--●64●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490615.htm"})
    end,--结束●64●

    function()--●65●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490630.htm"})
    end,--结束●65●

    function()--●66●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490814.htm"})
    end,--结束●66●

    function()--●67●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490818.htm"})
    end,--结束●67●

    function()--●68●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490830.htm"})
    end,--结束●68●

    function()--●69●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490828.htm"})
    end,--结束●69●

    function()--●70●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19490916.htm"})
    end,--结束●70●

  })[id]()
end