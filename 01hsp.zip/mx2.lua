--二卷目录♥♥♥♥♥♥
require"import"
import "android.widget.*"
import "android.view.*"
function onKeyDown()end
function getStatusBarHeight()
  local resid=activity.getResources().getIdentifier("status_bar_height","dimen","android")-- 3 2 5 5 2 7 3 2
  if resid>32552732*0 then
    return activity.getResources().getDimensionPixelSize(resid*((32552732-12345678)/2-10000000-(103001+525)))
  end
end


--下面是顶部颜色，可以设置渐变
local clr1=0xFF333333--0xFF000000--0xFF9CCC65--0xFF508CFE--0xFF66BB6A--0xFFC0CA33--0xFF2196F3
local clr2=0xFF333333--0xFFFAFAFA--0xFF66BB6A--0xFF3AB8FE--0xFF388E3C--0xFFFDD835--0xFF29B6F6

jdpuk={
  LinearLayout,
  orientation="vertical",
  layout_width="fill",
  layout_height="fill",
  {
    LinearLayout,
    layout_width="fill",
    --backgroundColor="#9CCC65",
    backgroundDrawable=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,{clr1,clr2}),--3-2-5-5-2-7-3-2--
    paddingTop=getStatusBarHeight(),
    {
      ToolBar,
      --backgroundColor="#9CCC65",
      backgroundColor=0,
      backgroundDrawable=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,{clr1,clr2}),--JDPUK
      layout_width="fill",
      layout_height="60dp",
      titleText="毛选第二卷",--♥♥♥
      --subTitle="32552732",
      returnButtonEnabled=true,
      elevation="-480dp",--未找到改变效果
    },
  },
  {
    ScrollView,
    layout_width="fill",
    layout_height="fill",
    verticalScrollBarEnabled=(3255==2732),
    verticalFadingEdgeEnabled=(not 32552732==32552732),
    overScrollMode=View.OVER_SCROLL_NEVER-(32552732*0),
    {
      RelativeLayout,
      layout_width="fill",
      layout_height="fill",

      {
        LinearLayout,
        orientation="vertical",
        layout_width="fill",

        {
          LinearLayout,
          --CardView,
          layout_margin="10dp",--上目录向内居中
          --CardBackgroundColor="#FFEEEEEE",
          layout_width="fill",
          --radius="1dp",--没有改变效果同下
          --elevation="1dp",
          {
            LinearLayout,
            layout_width="fill",
            orientation="vertical",
            {
              ListView,
              id="list",
              layout_width="fill",
              layout_height="2350dp",--♦♦♦显示所有按钮的框的长度
              dividerHeight="0dp",--项目间的横线
            },
          },
        },
        {
          LinearLayout,
          orientation="vertical",
          layout_margin="20dp",--项目推出边界
          layout_width="fill",
          layout_height="50dp",--下边距提高
          gravity="center",
        },
      },
    },
  },
}

activity.setContentView(loadlayout(jdpuk))

adpd={
  {
    text={
      text="1.反对日本进攻的方针、办法和前途",--●1●
    },
  },
  {
    text={
      text="2.为动员一切力量争取抗战胜利而斗争",--●2●
    },
  },
  {
    text={
      text="3.反对自由主义",--●3●
    },
  },
  {
    text={
      text="4.国共合作成立后的迫切任务",--●4●
    },
  },
  {
    text={
      text="5.和英国记者贝特兰的谈话",--●5●
    },
  },
  {
    text={
      text="6.上海太原失陷以后抗日战争的形势和任务",--●6●
    },
  },
  {
    text={
      text="7.陕甘宁边区政府第八路军后方留守处布告",--●7●
    },
  },
  {
    text={
      text="8.抗日游击战争的战略问题",--●8●
    },
  },
  {
    text={
      text="9.论持久战",--●9●
    },
  },
  {
    text={
      text="10.1中国共产党在民族战争中的地位",--●10●
    },
  },
  {
    text={
      text="10.2抗日民族战争与抗日民族统一战线发展的新阶段",--●10.2●
    },
  },
  {
    text={
      text="11.统一战线中的独立自主问题",--●11●
    },
  },
  {
    text={
      text="12.战争和战略问题",--●12●
    },
  },
  {
    text={
      text="13.五四运动.",--●13●
    },
  },
  {
    text={
      text="14.青年运动的方向",--●14●
    },
  },
  {
    text={
      text="15.反对投降活动",--●15●
    },
  },
  {
    text={
      text="16.必须制裁反动派",--●16●
    },
  },
  {
    text={
      text="17.关于国际新形势对新华日报记者的谈话",--●17●
    },
  },
  {
    text={
      text="18.和中央社、扫荡报、新民报三记者的谈话",--●18●
    },
  },
  {
    text={
      text="19.苏联利益和人类利益的一致",--●19●
    },
  },
  {
    text={
      text="20.《共产党人》发刊词",--●20●
    },
  },
  {
    text={
      text="21.目前形势和党的任务",--●21●
    },
  },
  {
    text={
      text="22.大量吸收知识分子",--●22●
    },
  },
  {
    text={
      text="23.1中国革命和中国共产党",--●23●
    },
  },
  {
    text={
      text="23.2中国革命和中国共产党",--●23.2●
    },
  },
  {
    text={
      text="24.斯大林是中国人民的朋友",--●24●
    },
  },
  {
    text={
      text="25.纪念白求恩",--●25●
    },
  },
  {
    text={
      text="26.新民主主义论",--●26●
    },
  },
  {
    text={
      text="27.克服投降危险，力争时局好转",--●27●
    },
  },
  {
    text={
      text="28.团结一切抗日力量，反对反共顽固派",--●28●
    },
  },
  {
    text={
      text="29.1向国民党的十点要求",--●29●
    },
  },
  {
    text={
      text="29.2延安民众讨汪拥蒋大会通电",--●29.2.●
    },
  },
  {
    text={
      text="30.《中国工人》发刊词",--●30●
    },
  },
  {
    text={
      text="31.必须强调团结和进步",--●31●
    },
  },
  {
    text={
      text="31.2中共中央关于目前时局与党的任务的决定",--●31.2●
    },
  },
  {
    text={
      text="32.新民主主义的宪政",--●32●
    },
  },
  {
    text={
      text="33.抗日根据地的政权问题",--●33●
    },
  },
  {
    text={
      text="34.目前抗日统一战线中的策略问题",--●34●
    },
  },
  {
    text={
      text="35.放手发展抗日力量，抵抗反共顽固派的进攻",--●35●
    },
  },
  {
    text={
      text="36.团结到底",--●36●
    },
  },
  {
    text={
      text="37.论政策",--●37●
    },
  },
  {
    text={
      text="38.为皖南事变发表的命令和谈话",--●38●
    },
  },
  {
    text={
      text="39.打退第二次反共高潮后的时局",--●39●
    },
  },
  {
    text={
      text="40.关于打退第二次反共高潮的总结",--●40●
    },
  },
}

items={
  LinearLayout,
  layout_width="fill",
  orientation="horizontal",
  {
    RelativeLayout,
    layout_width="fill",
    gravity="center|left",
    layout_marginTop="15dp",--♦♦♦上栏目触控效果间距
    layout_marginBottom="15dp",--♦♦♦下栏目触控效果间距
    layout_marginLeft="12dp",--所有项目右位移
    layout_marginRight="12dp",--所有项目左位移
    {
      TextView,
      id="text",
      textSize="16sp",--项目字体大小
      textColor="#505050",
    },
    {
      TextView,
      layout_alignParentRight=true,--32552732
      text="⟩",--箭头♥♥♥
      textSize="15sp",--项目右箭头大小
      textColor="#888888",
    },
  },
}

adapter=LuaAdapter(this,adpd,items)
list.Adapter=adapter
list.onItemClick=function(adp,view,pos,id)
  ({
    function()--●1●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19370723.htm"})
    end,--结束●1●

    function()--●2●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19370825.htm"})
    end,--结束●2●

    function()--●3●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19370907.htm"})
    end,--结束●3●

    function()--●4●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19370929.htm"})
    end,--结束●4●

    function()--●5●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19371025.htm"})
    end,--结束●5●

    function()--●6●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19371112.htm"})
    end,--结束●6●

    function()--●7●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19380515.htm"})
    end,--结束●7●

    function()--●8●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193805.htm"})
    end,--结束●8●

    function()--●9●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193805b.htm"})
    end,--结束●9●

    function()--●10●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19381014.htm"})
    end,--结束●10●

    function()--●10.2●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19381012aa.htm"})
    end,--结束●10.2●

    function()--●11●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19381105.htm"})
    end,--结束●11●

    function()--●12●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19381106.htm"})
    end,--结束●12●

    function()--●13●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19390501.htm"})
    end,--结束●13●

    function()--●14●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19390504.htm"})
    end,--结束●14●

    function()--●15●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19390630.htm"})
    end,--结束●15●

    function()--●16●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19390801.htm"})
    end,--结束●16●

    function()--●17●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19390901.htm"})
    end,--结束●17●

    function()--●18●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19390916.htm"})
    end,--结束●18●

    function()--●19●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19390928.htm"})
    end,--结束●19●

    function()--●20●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19391004.htm"})
    end,--结束●20●

    function()--●21●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19391010.htm"})
    end,--结束●21●

    function()--●22●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19391201.htm"})
    end,--结束●22●

    function()--●23●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193912.htm"})
    end,--结束●23●

    function()--●23.2●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-193912aa.htm"})
    end,--结束●23.2●

    function()--●24●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19391220.htm"})
    end,--结束●24●

    function()--●25●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19391221.htm"})
    end,--结束●25●

    function()--●26●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-194001.htm"})
    end,--结束●26●

    function()--●27●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400128.htm"})
    end,--结束●27●

    function()--●28●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400201.htm"})
    end,--结束●28●

    function()--●29●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400201b.htm"})
    end,--结束●29●

    function()--●29.2●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400201baa.htm"})
    end,--结束●29.2●

    function()--●30●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400207.htm"})
    end,--结束●30●

    function()--●31●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400207b.htm"})
    end,--结束●31●

    function()--●31.2●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400201aa.htm"})
    end,--结束●31.2●

    function()--●32●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400220.htm"})
    end,--结束●32●

    function()--●33●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400306.htm"})
    end,--结束●33●

    function()--●34●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400311.htm"})
    end,--结束●34●

    function()--●35●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400504.htm"})
    end,--结束●35●

    function()--●36●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19400705.htm"})
    end,--结束●36●

    function()--●37●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19401225.htm"})
    end,--结束●37●

    function()--●38●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19410120.htm"})
    end,--结束●38●

    function()--●39●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19410318.htm"})
    end,--结束●36●

    function()--●40●
      进入子页面("浏览器",{链接="https://www.marxists.org/chinese/maozedong/marxist.org-chinese-mao-19410508.htm"})
    end,--结束●40●

  })[id]()
end